package com.smart;

public class WaiterManager {
    public void addWaiter(Waiter waiter){
    	System.out.println("add Waiter...");
    }
    public void addNaiveWaiter(NaiveWaiter nw){
    	System.out.println("add NaiveWaiter...");
    }
    
}
