package com.smart.instrument;
public class Test {
	public static void main(String[] args) {
		System.out.println("I'm in main() of Test...");
	}
}
