package com.smart;

public interface Seller {
  int sell(String goods, String clientName);
}
