package com.smart;

public class CuteNaiveWaiter extends NaiveWaiter {

}
