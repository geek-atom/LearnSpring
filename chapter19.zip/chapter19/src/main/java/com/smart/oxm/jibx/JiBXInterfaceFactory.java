package com.smart.oxm.jibx;
import java.util.ArrayList;
import java.util.List;
public class JiBXInterfaceFactory {
	/**
	 * 获取List实现类实例
	 * @return
	 */
	public static List getArrayListInstance(){
		return new ArrayList();
	}
}
