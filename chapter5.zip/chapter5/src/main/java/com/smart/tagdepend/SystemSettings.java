package com.smart.tagdepend;

public class SystemSettings {
   public static int SESSION_TIMEOUT = 30;
   public static int REFRESH_CYCLE = 60;
}
