package com.smart.tagdepend;

import java.util.TimerTask;

public class CacheTask extends TimerTask {
	public void run() {
		System.out.println("doing clean cache");
	}

}
