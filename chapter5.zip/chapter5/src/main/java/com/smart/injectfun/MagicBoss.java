package com.smart.injectfun;

public interface MagicBoss {
   Car getCar(); 
}
