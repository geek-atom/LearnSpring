package com.smart.attr;

public class Foo {
	private String iDCode;
	public void setIDCode(String iDcode) {
		this.iDCode = iDcode;
	}
}
