package com.smart.fb;

public interface CarBrandType {
   String HONG_QI = "红旗";
   String JI_LI = "吉利";
}
