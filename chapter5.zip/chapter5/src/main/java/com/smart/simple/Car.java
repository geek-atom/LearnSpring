package com.smart.simple;

public class Car {

}
