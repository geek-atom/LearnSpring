package com.smart.anno;

import org.springframework.stereotype.Component;

@Component("userDao")
public class UserDao {

}
