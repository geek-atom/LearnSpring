package com.smart.groovy;

import com.smart.anno.*;


public class XmlUserDao implements UserDao {
}
