package com.smart.groovy;


public class DbUserDao implements UserDao{
}
