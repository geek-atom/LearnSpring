package com.smart.groovy;

import org.springframework.stereotype.Component;

@Component
public class MailService {

}
