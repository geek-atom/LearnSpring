package com.smart.groovy;

import org.springframework.stereotype.Component;


public interface UserDao {

}
