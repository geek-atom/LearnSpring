package com.smart.concept;

public interface TopicDao {

	void removeTopic(int topicId);



}
