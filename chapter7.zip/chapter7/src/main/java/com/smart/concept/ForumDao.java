package com.smart.concept;

public interface ForumDao {

	void create(Forum forum);

}
