package com.smart.concept;

public class User {

}
