package com.smart.proxy;

public interface ForumService {
	void removeTopic(int topicId);
	void removeForum(int forumId);
}
