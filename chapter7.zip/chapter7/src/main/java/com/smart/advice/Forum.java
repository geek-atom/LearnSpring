package com.smart.advice;

public class Forum {
	private int forumId;

	public int getForumId() {
		return forumId;
	}

	public void setForumId(int forumId) {
		this.forumId = forumId;
	}

}
