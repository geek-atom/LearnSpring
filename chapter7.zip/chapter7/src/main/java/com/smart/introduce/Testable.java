package com.smart.introduce;

public interface Testable {
  void test();
}
