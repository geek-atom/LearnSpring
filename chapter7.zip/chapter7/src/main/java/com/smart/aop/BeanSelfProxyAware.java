package com.smart.aop;

public interface BeanSelfProxyAware {
    void setSelfProxy(Object object);
}