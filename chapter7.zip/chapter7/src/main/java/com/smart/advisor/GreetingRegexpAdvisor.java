package com.smart.advisor;

import org.springframework.aop.support.RegexpMethodPointcutAdvisor;

public class GreetingRegexpAdvisor extends RegexpMethodPointcutAdvisor {
   
}
