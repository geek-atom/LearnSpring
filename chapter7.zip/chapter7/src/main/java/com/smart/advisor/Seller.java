package com.smart.advisor;
public class Seller {
	public void greetTo(String name) {
		System.out.println("seller greet to "+name+"...");
	}
}
