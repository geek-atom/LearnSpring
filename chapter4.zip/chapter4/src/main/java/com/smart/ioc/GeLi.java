package com.smart.ioc;

public interface GeLi {
	void responseAsk(String saying);
}
