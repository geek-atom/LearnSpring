package com.smart.domain;

import java.io.Serializable;

public class Topic implements Serializable {
	
}
